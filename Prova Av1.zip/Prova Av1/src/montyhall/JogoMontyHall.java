package montyhall;


import java.util.Scanner;
import java.util.Random;

public class JogoMontyHall {
    public static void main(String[] args) {

        int porta = 0;

        Scanner in = new Scanner(System.in);

        do {
            System.out.println("******Bem-vindo ao jogo Monty Hall!******");
            System.out.println("Escolha uma porta (1, 2 ou 3)");
            System.out.println("Escolha uma porta para entrar: ");
            porta = in.nextInt();
            System.out.println("*****************************");
            System.out.println();
            switch (porta) {
                case 1:
                    porta1();
                    break;
                case 2:
                    porta2();
                    break;
                case 3:
                    porta3();
                    break;
                default:
                    System.out.println("!");
                    break;
            }
        } while (porta != 0);

    }

    private static void porta1() {

        int portaUm = 0;
        Scanner in = new Scanner(System.in);
        Random rdn = new Random();

        System.out.print("\nEntre na porta desejada: ");
        portaUm = in.nextInt();


        int portaEscolhida = rdn.nextInt(101);


        if (portaEscolhida == portaUm) {
            System.out.println("\nPorta vazia!");
        }
        in.close();
    }

    private static void porta2() {
        int portaDois = 0;
        Scanner in = new Scanner(System.in);
        Random rdn = new Random();

        System.out.print("\nEntre na porta desejada: ");
        portaDois = in.nextInt();

        int portaEscolhida = rdn.nextInt(101);

        if (portaEscolhida == portaDois) {
            System.out.println("\nPorta premiada!");
        }
        in.close();
    }

    private static void porta3() {
        int portaTres = 0;
        Scanner in = new Scanner(System.in);
        Random rdn = new Random();

        System.out.print("\nEntre na porta desejada: ");
        portaTres = in.nextInt();

        int portaEscolhida = rdn.nextInt(101);

        if (portaEscolhida == portaTres) {
            System.out.println("\nPorta premiada!");
        }
        in.close();

    }

}


